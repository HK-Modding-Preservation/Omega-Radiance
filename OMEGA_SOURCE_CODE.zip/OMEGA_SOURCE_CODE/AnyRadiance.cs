﻿using System.Diagnostics;
using System.Reflection;
using JetBrains.Annotations;
using Modding;
using UnityEngine;

namespace AnyRadiance {
    [UsedImplicitly]
    public class AnyRadiance : Mod, ITogglableMod {
        public static AnyRadiance instance;

        public AnyRadiance() : base("Omega Radiance") { }

        public override void Initialize() {
            instance = this;

            Log("Initalizing.");
            ModHooks.AfterSavegameLoadHook += AfterSaveGameLoad;
            ModHooks.NewGameHook += AddComponent;
            ModHooks.LanguageGetHook += LangGet;
        }


        public override string GetVersion(){
            return "1.1";
        }

        private static string LangGet(string key, string sheettitle, string orig) {
            if (key != null) {
                switch (key) {
                    case "NAME_FINAL_BOSS": return ("Omega Radiance");
                    case "ABSOLUTE_RADIANCE_SUPER": return "OMEGA";
                    case "GG_S_RADIANCE": return "God of power.";
                    case "ABSOLUTE_RADIANCE_MAIN": return ("RADIANCE");
                    case "GODSEEKER_RADIANCE_STATUE": return "Made by talezshadid\nBuilt off Any radiance by Bobfred\n Testers: AxtonKincaid, shadowmaster7 and Anika\n  Coding help: EarlyHemisphere";
                    default: return Language.Language.GetInternal(key, sheettitle);
                }
            }
            return orig;
        }

        private static void AfterSaveGameLoad(SaveGameData data) {
            AddComponent();
        }

        private static void AddComponent() {
            GameManager.instance.gameObject.AddComponent<AbsFinder>();
        }

        public void Unload() {
            ModHooks.AfterSavegameLoadHook -= AfterSaveGameLoad;
            ModHooks.NewGameHook -= AddComponent;
            ModHooks.LanguageGetHook -= LangGet;
            GameManager instance = GameManager.instance;
            AbsFinder absFinder = ((instance != null) ? instance.gameObject.GetComponent<AbsFinder>() : null);
            if (!(absFinder == null))
            {
                Object.Destroy(absFinder);
            }
        }
    }
}